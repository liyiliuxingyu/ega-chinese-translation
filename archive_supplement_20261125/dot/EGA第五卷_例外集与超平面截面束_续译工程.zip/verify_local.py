"""Small finite-plane models only, not a substitute for the proof."""
from itertools import product

def homogeneous(q):
    return {tuple(a*pow(next(x for x in v if x),-1,q)%q for a in v)
            for v in product(range(q),repeat=3) if any(v)}
def incidence(line,point,q):
    return sum(a*b for a,b in zip(line,point))%q==0

for q in (2,3,5):
    pts=homogeneous(q)
    lines={ell:{x for x in pts if incidence(ell,x,q)} for ell in pts}
    assert len(pts)==q*q+q+1
    assert all(len(x)==q+1 for x in lines.values())
    assert all(sum(p in line for line in lines.values())==q+1 for p in pts)
    assert all(len(a&b)==1 for l,a in lines.items() for m,b in lines.items() if l!=m)
    # A single point is codimension two and some rational line avoids it.
    assert all(any(p not in line for line in lines.values()) for p in pts)
    # The full set of rational points is also a zero-dimensional closed set,
    # but no rational line avoids it.
    assert not any(not (line & pts) for line in lines.values())
    # A line minus a specified point misses each other line through that point.
    for l,M in lines.items():
        for p in M:
            assert sum(not (N & (M-{p})) for N in lines.values())==q
            assert all(M & N for N in lines.values())
    print(f"PASS: P^2(F_{q}), {len(pts)} points/lines, closed and punctured examples")
