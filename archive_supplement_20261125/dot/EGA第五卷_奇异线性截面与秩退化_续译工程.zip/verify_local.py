"""Finite Schubert rank counts and coordinate minors; not a general verifier."""
from itertools import product
from math import prod
import sympy as sp

def gaussian(r,m,q):
    return prod(q**(r-j)-1 for j in range(m))//prod(q**(m-j)-1 for j in range(m))

def rref(V,q):
    V=[list(v) for v in V]; row=0
    for j in range(len(V[0]) if V else 0):
        i=next((i for i in range(row,len(V)) if V[i][j]),None)
        if i is None:continue
        V[row],V[i]=V[i],V[row]
        k=pow(V[row][j],-1,q)
        V[row]=[(x*k)%q for x in V[row]]
        for i,v in enumerate(V):
            if i!=row: V[i]=[(b-v[j]*a)%q for a,b in zip(V[row],v)]
        row+=1
    return tuple(tuple(v) for v in V[:row])
from collections import Counter

total=0
for q,N in product((2,3),range(1,6)):
    points={tuple((x*pow(next(a for a in v if a),-1,q))%q for x in v)
            for v in product(range(q),repeat=N) if any(v)}
    G={()}
    for m in range(N+1):
        assert len(G)==gaussian(N,m,q)
        for n in range(m,N+1):
            got=Counter(m-len(rref([row[:n] for row in H],q)) for H in G)
            want={}
            for k in range(min(m,N-n)+1):
                t=n-m+k
                d=N-m-t
                want[k]=gaussian(n,t,q)*gaussian(N-n,d,q)*q**((n-t)*d)
                dim=t*(n-t)+d*(N-n-d)+(n-t)*d
                assert m*(N-m)-dim==k*(n-m+k)
                assert m*(N+1-m)-(n+dim)==(k-1)*(n-m)+k*k
            assert got==want,(q,N,m,n,got,want)
            total+=sum(got.values())
        if m<N:
            G={U for H,w in product(G,points) if len(U:=rref((*H,w),q))==m+1}
print(f'PASS {total} finite quotient/tangent comparisons with Gaussian Schubert ranks')
a,b,c,d=sp.symbols('a b c d')
M=sp.Matrix([[1,0,a,b],[0,1,c,d]])
first=M[:,[0,2,3]]
assert [first[:,[i,j]].det() for i,j in [(0,1),(0,2),(1,2)]]==[c,d,a*d-b*c]
assert sp.Matrix([c,d]).jacobian([a,b,c,d]).rank()==2
phi=sp.Matrix([[a,b],[c,d]]).det()
grad=sp.Matrix([phi]).jacobian([a,b,c,d])
assert grad.subs({a:1,b:0,c:0,d:0}).rank()==1
assert grad.subs(dict.fromkeys([a,b,c,d],0)).rank()==0
print('PASS representative quotient chart and smooth/excess strata Jacobian checks')
