EGA第五卷预备笔记，第119批，第12节续校。法文物理69页命题6.1起至法71页可略去V''结论，英46–47。校订已有第十九版旧译，不修改公开仓库，不扩大为全文完成。下一从法71页末 D’autre part, dans … 续，正式EGA IV.1仍另从物理221/223(1.1.1)推进。
python3 verify.py 核本包；python3 verify_local.py 核 Grassmann 有限图和局部行列式（SymPy）；在副本 bash build.sh 两遍 XeLaTeX，ctexbook 默认版心及 Fandol 字体，使用 ctex、amsmath、amssymb、hyperref。
