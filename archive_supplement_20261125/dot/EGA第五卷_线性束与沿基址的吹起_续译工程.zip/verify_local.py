"""Finite and polynomial models, not a replacement for the proof."""
from itertools import product

# F4 with primitive a satisfying a^2+a+1=0. Use u=a^2.
def mul(x,y):
    z=0
    for _ in range(2):
        if y&1: z ^= x
        y >>= 1
        x <<= 1
        if x&4: x ^= 7
    return z
u=mul(2,2)
assert u==3 and [x for x in range(4) if mul(x,x)==u]==[2]
crit=[(x,y,z) for x,y,z in product(range(4),repeat=3)
      if y==z==0 and mul(x,x)^mul(y,z)^u==0]
assert crit==[(2,0,0)]
assert all(v==0 for v,y,z in product(range(4),repeat=3)
           if y==z==0 and mul(v,v)^mul(y,z)==0)
print('PASS: F4 model, unique singular point and smooth projective tangent cone')
try:
    from sympy import groebner, symbols
except ModuleNotFoundError:
    raise SystemExit("需要 SymPy：python3 -m pip install sympy")
x,y,w,U,V=symbols('x y w U V')
for p in (2,3,5):
    def eliminate(f,g):
        return [h.as_expr() for h in groebner([U-f*w,V-g*w],w,U,V,x,y,modulus=p).polys
                if not h.as_expr().has(w)]
    for f,g in [(x,y),(x*x,y*y),(x,y*y+x)]:
        got=eliminate(f,g)
        rels=[f*V-g*U]
        G=groebner(rels,U,V,x,y,modulus=p)
        H=groebner(got,U,V,x,y,modulus=p)
        assert all(G.reduce(h)[1]==0 for h in got)
        assert all(H.reduce(h)[1]==0 for h in rels)
    got=eliminate(x,x*y)
    H=groebner(got,U,V,x,y,modulus=p)
    assert H.reduce(V-y*U)[1]==0
    G=groebner([x*(V-y*U)],U,V,x,y,modulus=p)
    assert G.reduce(V-y*U)[1]!=0
    print(f'PASS: F{p} regular-pair Rees and nonregular counterexample')
