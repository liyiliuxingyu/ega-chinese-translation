EGA 第五卷预备笔记，第 116 批
入口：EGA第五卷_线性束与沿基址的吹起.tex。
PDF 使用 ctexbook 与 Fandol（随完整 TeX Live 发行，不必额外下载字体），可用 XeLaTeX。所需宏包 ctex、amsmath、amssymb、geometry、hyperref；执行 bash build.sh 编译两遍。Windows 可在含 UTF-8 及 TeX 的终端手工运行两遍 XeLaTeX；必要时把 kpsewhich tex-text.tec 返回的文件复制到临时构建目录。

续作：先运行 python3 verify.py 校验原包内容，再在副本中运行 bash build.sh；可选 python3 verify_local.py（需要 SymPy）复核有限算例与消元。重编 PDF 含不同元数据时不强求文件字节相同；本批比较的是可见页面像素和提取正文。
下一批从法59、英40的划去命题10.3开始，明确版面状态后，续查10.4（法59–60，英40–41）。正文写正确的，底本误字或不确定处放脚注，不补造缺稿。本批原文摘件只覆盖所列物理页，边页仍可见毗邻文字。
独立续译，不对已经公开的第十八版作修改。正式 EGA IV.1 的物理221提要、223的(1.1.1)仍为另一条线。
