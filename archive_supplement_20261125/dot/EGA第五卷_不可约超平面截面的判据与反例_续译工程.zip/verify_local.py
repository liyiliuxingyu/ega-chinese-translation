import sympy as s
x,y,z,w,a,b,c,L=s.symbols('x y z w a b c L')
q=x*z-y*y
assert [s.diff(q,u) for u in (x,y,z,w)]==[z,-2*y,x,0]
assert s.expand((b*b-4*a*c).subs({a:z,b:-2*y,c:x}))==-4*q
assert q.subs(x,0)==-y*y
assert s.expand(q.subs(z,x)-(x-y)*(x+y))==0
p=s.Poly((a*x+b*y+c*z).subs({x:1,y:L,z:L**2}),L)
assert s.discriminant(p)==b*b-4*a*c
print('PASS: tangent quadric discriminant, double line and distinct rulings, exact')
