第111批，第五卷第一篇命题8.18。核对法物理49–50和英物理34，与第十八版第010批旧译对照；不是首次翻译。主TeX/PDF为校订稿，原旧稿仅保留摘录。
以二次锥的非约化双线否定原写法，用整截面见证修复必要充分性，并补出正规化只保持几何不可约性的原因。
重建：bash build.sh；要 XeLaTeX、CTeX/Fandol、AMS、geometry、hyperref。
验证：python3 verify.py；python3 verify_local.py（SymPy，是局部式核对，不替代证明）。
下一处：法物理50页下部“I(l) reste à expliciter les conditions a) et b) de 8.18”，延至51页，英物理34页末至35页，核第011批旧译，并明确线性系 L 与其中心 L⁰。
v18 1210页合订稿未改，109–111单独保存。正式IV章另起，印本IV.1物理221，(1.1.1)物理223。
