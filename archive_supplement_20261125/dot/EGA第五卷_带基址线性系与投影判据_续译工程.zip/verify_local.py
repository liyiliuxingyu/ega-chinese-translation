from sympy import Matrix, Poly, symbols, discriminant, expand
for q in range(0, 9):
    for v in range(q+3, q+12):
        pi = Matrix.eye(v)[q+1:, :]
        assert pi.rank() == v-q-1
        assert len(pi.nullspace()) == q+1
        assert len(pi[1:, :].nullspace())-1 == q+1
        assert len(pi[2:, :].nullspace())-1 == q+2
a,b,c,x,y,z,s,t,e = symbols('a b c x y z s t e')
# On the blowup chart y=x*s, z=x*t at 0 in A³.
F = a*x+b*y+c*z
assert expand(F.subs({y:x*s,z:x*t})-x*(a+b*s+c*t)) == 0
assert Poly(a+b*s+c*t,s,t).total_degree() == 1
# A conic meets a generic hyperplane (line) in two geometric points.
assert discriminant(a+b*t+c*t**2,t)==b**2-4*a*c
# Point-centered projection of P² in chart y=1, with center [0:0:1].
# g([x:1:z]) is x; z and the free coordinates on a second P² survive.
m,n = symbols('m n')
assert Matrix([x]).jacobian([x,z,m,n]).rank()==1
print('PASS: 81 projection rank cases, blowup factor, generic conic, product chart')
