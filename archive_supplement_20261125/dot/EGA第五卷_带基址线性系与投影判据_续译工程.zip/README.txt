EGA 第五卷预备笔记第112批：带基址线性系与投影判据
本包回校当前第十八版已有第011–012批，不是首次翻译，也未覆盖公开合订工程。
随包：ctexbook 成品 PDF 与独立 TeX、法稿50–52和英稿34–36摘页、旧译摘录、核对记录、进度与验证脚本。
python3 verify.py 验证 SHA；可选 python3 verify_local.py 检查投影模型。bash build.sh 使用 XeLaTeX、ctex、Fandol、AMS、geometry、hyperref 重编。
旧译摘录保留两段 DOT_IMPORT 标记，为固定公开提交内对应片段，不是整个远端 blob。基线_v5_03_06.tex 只代表原 §§3–6 工作参考，不是第十八版合订源码。
接续：法稿物理53页第9节9.1，英稿物理36页；9.2附记续法54页首。第五卷与正式 EGA IV.1 的页码独立。
