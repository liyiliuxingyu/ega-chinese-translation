"""Finite counts and a dual-number model, not a general proof."""
from itertools import product
from math import prod

def gaussian(r,m,q):
    return prod(q**(r-j)-1 for j in range(m))//prod(q**(m-j)-1 for j in range(m))

def rref(V,q):
    V=[list(v) for v in V]; row=0
    for j in range(len(V[0]) if V else 0):
        i=next((i for i in range(row,len(V)) if V[i][j]),None)
        if i is None:continue
        V[row],V[i]=V[i],V[row]
        k=pow(V[row][j],-1,q)
        V[row]=[(x*k)%q for x in V[row]]
        for i,v in enumerate(V):
            if i!=row: V[i]=[(b-v[j]*a)%q for a,b in zip(V[row],v)]
        row+=1
    return tuple(tuple(v) for v in V[:row])
def extend(q,r):
    points=sorted({tuple((x*pow(next(a for a in v if a),-1,q))%q for x in v)
                   for v in product(range(q),repeat=r) if any(v)})
    G={()}
    for m in range(r+1):
        assert len(G)==gaussian(r,m,q)
        counts=[0]*len(points)
        for H in G:
            members=[k for k,v in enumerate(points)
                     if all(sum(a*b for a,b in zip(v,w))%q==0 for w in H)]
            assert len(members)==(q**(r-m)-1)//(q-1)
            for k in members:counts[k]+=1
        assert set(counts)=={gaussian(r-1,m,q) if m<r else 0}
        if m<r:G={U for H,w in product(G,points) if len(U:=rref((*H,w),q))==m+1}
    return len(points)
for q in (2,3):
    for r in (2,3,4):
        print('PASS',q,r,extend(q,r),'projective points, all Grassmann ranks')

# (a,b) represents a+b*epsilon over F3, epsilon^2=0.
def mul(u,v):return ((u[0]*v[0])%3,(u[0]*v[1]+u[1]*v[0])%3)
assert mul((0,1),(0,1))==(0,0)
point=((0,0),(1,0))
form=((1,0),(0,2))
pairs=[mul(z,w) for z,w in zip(point,form)]
value=tuple(sum(c)%3 for c in zip(*pairs))
assert value==(0,2) and value[0]==0 and value!=(0,0)
print('PASS dual numbers: geometrically incident but nonzero scheme-theoretic evaluation')
