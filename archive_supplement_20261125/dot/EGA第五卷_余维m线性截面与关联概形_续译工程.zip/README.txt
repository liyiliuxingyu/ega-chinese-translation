EGA 第五卷预备笔记，第117批。第12节开头：余维m线性截面与关联概形。
独立续作，不改公开第十九版。第十九版已有本段英基线译文；本包附逐段法英回校和独立核验，不计为原来从未翻译的页。法原本64–66、英43–44；末页只回校第一段，下一从命题2.1回顾继续。正式卷IV.1未动。

用 python3 verify.py 先核对原包，python3 verify_local.py 核对有限域关联计数及非约化示例。另在副本用 bash build.sh 两遍 XeLaTeX。中文采用 ctexbook 默认版心和 TeX Live Fandol 字体；宏包 ctex、amsmath、amssymb、hyperref。Windows 下可在 UTF-8 终端手工 XeLaTeX 两次。
