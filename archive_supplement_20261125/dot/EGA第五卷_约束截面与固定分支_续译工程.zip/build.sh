#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -e tex-text.tec ]; then
  t=$(kpsewhich tex-text.tec)
  cp "$t" tex-text.tec
  trap 'rm -f tex-text.tec' EXIT
fi
s='EGA第五卷_约束截面与固定分支'
for pass in 1 2; do xelatex -interaction=nonstopmode -halt-on-error "$s.tex" >"pass-$pass.txt"; done
if grep -E 'Warning|Overfull|Missing character|^!' "$s.log"; then exit 1; fi
