from itertools import product
from math import comb
for p in (2,3,5):
 for x,y in product(range(p),repeat=2):
  if x==y==0: continue
  for n in range(2,6):
   l=x or y
   for j in (1,2): assert pow(l,j,p)!=0  # m=1 in affine normalization
 for u,v in product(range(1,p),range(p)):
  assert (u*u*pow(u,-1,p)%p,u*v*pow(u,-1,p)%p)==(u,v)
  assert (u**3*pow(u*u,-1,p)%p,u*u*v*pow(u*u,-1,p)%p)==(u,v)
 for n in range(1,6):
  src={(i,n-i):comb(n,i)%p for i in range(n+1) if comb(n,i)%p}
  pull={(i+j,j):c for (i,j),c in src.items()}
  assert min(i for i,j in pull)==n
  assert (n,0) in pull and (n,n) in pull
print('3 finite fields: affine base separation, ratios and blow-up factors')
