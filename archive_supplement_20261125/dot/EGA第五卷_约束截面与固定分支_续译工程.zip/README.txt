EGA 第五卷预备笔记第114批：约束截面与固定分支
法稿54–55页与英编稿37–38页对读，回校命题9.3全部及证明。正文补明全截面的充分条件；逐项区分原稿、旧英译与编辑补证。
包内：高清 PDF、独立 ctexbook TeX、法英摘页、固定旧译摘录、对读与核验、页码对照、进度与校验工具。
python3 verify.py 验 SHA；python3 verify_local.py 核具体模型；bash build.sh 用 XeLaTeX、ctex、Fandol、AMS、geometry、hyperref 重编。基线_v5_03_06.tex 为单独历史对照，不是当前合订稿，也不被本批主 TeX 引用。
下一处从法55页“结合8.18”引出9.4、英38页相应段落续；勿补造残缺定理。公开合订v18与正式IV.1均未改。
