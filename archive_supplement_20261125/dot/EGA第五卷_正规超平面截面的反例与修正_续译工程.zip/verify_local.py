"""Check polynomial identities, not independently a proof of the codimension theorem."""
import sympy as S
from itertools import product
t,a,b,c,d,s=S.symbols('t a b c d s')
X=[a,b,c,d]
forms=[t**3]+[x*x*z for x,z in product(X,[t,*X])]
assert len(set(forms))==21
o={t:1,a:0,b:0,c:0,d:0}
assert [f.subs(o) for f in forms]==[1]+[0]*20
assert S.expand((a*d-b*c).subs({b:a*s,d:c*s}))==0
for x in X:
    for z in [t,*X]:
        assert S.cancel((x*x*z)/(x**3)-z/x)==0
for f in forms[1:]:
    q=S.Poly(f.subs({b:a*s,d:c*s,t:1}),a,c)
    assert min(sum(m) for m in q.monoms())>=2
    assert all(S.diff(q.as_expr(),x).subs({a:0,c:0})==0 for x in (a,c))
# Blow-up of the affine chart of P^3 at the origin: total hyperplane inverse
# image along x chart, with x=0 the exceptional part.
x,y,z,p,q,A,B,C=S.symbols('x y z p q A B C')
assert S.expand((A*x+B*y+C*z).subs({y:x*p,z:x*q})-x*(A+B*p+C*q))==0
u,v,w,z=S.symbols('u v w z')
Q=u*z-v*w
g=[S.diff(Q,k) for k in (u,v,w,z)]
assert S.expand(g[0]*g[3]-g[1]*g[2])==Q
assert S.factor(Q.subs(z,0))==-v*w
assert tuple(S.groebner([Q.subs(z,u),*(S.diff(Q.subs(z,u),k) for k in (u,v,w))],u,v,w)) == (u,v,w)
print('PASS: both local contraction models, 20 quadratic vanishing tests, quadric dual identities')
