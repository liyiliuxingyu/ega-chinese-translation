from sympy import groebner,symbols
x,y,z=symbols("x y z")
G=groebner([x*y],x,y,z)
assert G.reduce(x)[1]==x and G.reduce(y)[1]==y
assert G.reduce(x*y)[1]==0
# On intersection, every product of two generators of (x,y) is
# quadratically zero in the cotangent quotient, and x,y remain independent.
H=groebner([x*x,x*y,y*y],x,y,z)
assert H.reduce(x+y)[1]==x+y and H.reduce(x-y)[1]==x-y
print("Crossing planes: zero-divisors and two independent normal linear classes; see text for local dimensions")
