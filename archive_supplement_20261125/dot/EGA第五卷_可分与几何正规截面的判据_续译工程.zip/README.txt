代数几何基础第五卷预备笔记／第109批：8.14、8.15、Remords 法英回校。
法物理46页后部起至48页8.16前，英物理32页，另对照旧第008批。新增是法文读法、勘误、论证和语境，不重复计为首次翻译。
运行 python3 verify.py 校验；python3 verify_local.py 做局部环代数核验（SymPy）；bash build.sh 重编，需要 XeLaTeX、CTeX、Fandol、AMS、geometry、hyperref。
法扫描171页 SHA256 24cf8204184b58b18a46e5f63ecc36d6e791b3c8c96a09daac93de96ebd8e830
英编稿112页 SHA256 23a20ef32fd16a1bd623c0c08ac080d04fc94f248de12133b713a19d6b0330d9
基线 TeX 仅为 §§3–6。下一批法48命题8.16、英33，先查历史译稿，继续核对连通性及无分歧范围。1158页合订、正式IV.1、公开快照均未改。
