EGA 第五卷预备笔记第113批：Veronese 变换与二阶奇点
回校法稿物理53页及54页首行，英编稿物理36页，旧译第013批。
随包：ctexbook 成品 PDF、独立 TeX、法英摘页、旧译摘录、页对照、审校记录、接续位置和校验脚本。
python3 verify.py 核 SHA256；python3 verify_local.py 核有限域的二次型、切平面和重根模型；bash build.sh 用 XeLaTeX、ctex、Fandol、AMS、geometry、hyperref 重编。将原 TeX 留在同一目录；此独立 TeX 不读取旧译或基线。基线_v5_03_06.tex 只供对照，不是 v18 合订源码。
下一批从法物理54页命题9.3题头、英物理37页开始，不重复法54首行。公开 v18 和正式第四卷第1部不因本包改变。
