from itertools import product
def q(x,terms,p):
 return sum(x[i]*x[j] for i,j in terms)%p
for p,d,terms,rad_size in [(3,3,[(i,i) for i in range(3)],1),
 (2,2,[(0,1)],1),(2,3,[(0,1),(2,2)],2),
 (2,5,[(0,1),(2,3),(4,4)],2),(2,1,[(0,0)],2)]:
 xs=list(product(range(p),repeat=d))
 basis=[tuple(int(i==j) for j in range(d)) for i in range(d)]
 r=[x for x in xs if all(not (q(tuple(a+b for a,b in zip(x,e)),terms,p)
        -q(x,terms,p)-q(e,terms,p))%p for e in basis)]
 assert len(r)==rad_size and all(q(x,terms,p)!=0 for x in r if any(x))
 print('Polar radical/projective smoothness model',p,d,len(xs),len(r))
for p in (2,3,5):
 for a,b in product(range(p),repeat=2):
  assert (-a*b)%p==0 if (a==0 or b==0) else (-a*b)%p!=0
 for t in range(p):
  if p==2: assert (t*t+t*t)%2==0
print('Split tangent cut: two distinct coordinate lines; char-2 square models checked')
