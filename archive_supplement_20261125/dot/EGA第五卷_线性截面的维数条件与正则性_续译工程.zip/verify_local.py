"""Finite linear models and one explicit Koszul test; not a general verifier."""
from itertools import product
from math import prod
import sympy as sp

def gaussian(r,m,q):
    return prod(q**(r-j)-1 for j in range(m))//prod(q**(m-j)-1 for j in range(m))

def rref(V,q):
    V=[list(v) for v in V]; row=0
    for j in range(len(V[0]) if V else 0):
        i=next((i for i in range(row,len(V)) if V[i][j]),None)
        if i is None:continue
        V[row],V[i]=V[i],V[row]
        k=pow(V[row][j],-1,q)
        V[row]=[(x*k)%q for x in V[row]]
        for i,v in enumerate(V):
            if i!=row: V[i]=[(b-v[j]*a)%q for a,b in zip(V[row],v)]
        row+=1
    return tuple(tuple(v) for v in V[:row])
def verify_projective_intersections(q,r):
    points=sorted({tuple((x*pow(next(a for a in v if a),-1,q))%q for x in v)
                   for v in product(range(q),repeat=r) if any(v)})
    spaces=[{()}]
    for m in range(r):
        spaces.append({U for H,w in product(spaces[-1],points)
                       if len(U:=rref((*H,w),q))==m+1})
    expr=lambda v,H: all(sum(a*b for a,b in zip(v,w))%q==0 for w in H)
    masks=[[{i for i,v in enumerate(points) if expr(v,H)} for H in G] for G in spaces]
    trials=0
    for c,m in product(range(r+1),repeat=2):
        counts=set()
        for a,A in enumerate(spaces[c]):
            for b,B in enumerate(spaces[m]):
                k=r-len(rref((*A,*B),q))
                assert len(masks[c][a] & masks[m][b])==(q**k-1)//(q-1)
                counts.add(k)
                trials+=1
        assert min(counts)==max(0,r-c-m)
    if r<=3:
        for m in range(r+1):
            bases={U for T in product(points,repeat=m) if len(U:=rref(T,q))==m}
            assert bases==spaces[m] and len(bases)==gaussian(r,m,q)
    return trials

total=sum(verify_projective_intersections(q,r) for q,r in product((2,3),(2,3,4)))
print(f'PASS {total} finite pairs of linear sections; independent tuple image checked in ranks 2–3')
x,y,a,b,c,d=sp.symbols('x y a b c d')
F=sp.Matrix([[x,y]])
P=sp.Matrix([[a,b],[c,d]])
G=F*P
def d2(M):
    return sp.Matrix([-M[1],M[0]])
assert (P*d2(G)-P.det()*d2(F)).applyfunc(sp.expand)==sp.zeros(2,1)
assert (G*d2(G)).applyfunc(sp.expand)==sp.zeros(1,1)
bad=sp.Matrix([[x,x*y]])
syzygy=sp.Matrix([-y,1])
assert bad*syzygy==sp.zeros(1,1) and d2(bad)==x*syzygy
print('PASS symbolic exterior-power change of Koszul basis; (x,xy) has a nonzero H1 class')
