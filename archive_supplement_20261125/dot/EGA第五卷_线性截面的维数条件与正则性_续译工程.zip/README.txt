EGA 第五卷预备笔记，第118批。第12节对前文第2—5节的推广：维数条件与正则性。
法文物理页66（命题2.1句起）、67/68（同一底稿再扫描）、69（止于5.7）；英编稿物理44—45页。回校旧译，不更改公开v19，也不把已有译文重计为新增全文。
下一处法69、英46“命题6.1”；正式印本EGA IV.1另从物理221/223（1.1.1）续。

运行 python3 verify.py 校验本包；python3 verify_local.py 校验有限域例与代数算式（后者需SymPy）。在副本中运行 bash build.sh 两遍 XeLaTeX，采用 ctexbook 默认版心与 Fandol 默认字体。需要 TeX Live 的 ctex、amsmath、amssymb、hyperref。
