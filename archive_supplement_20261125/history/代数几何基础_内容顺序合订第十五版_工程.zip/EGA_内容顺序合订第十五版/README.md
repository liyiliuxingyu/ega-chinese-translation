# 代数几何基础·中文译校合订本（第十五版）

## 内容与入口
- `main.pdf`：1052页当前译文合订本；`main.tex` 为分文件工程入口。
- `single.tex`：完整、可独立编译的合订本TeX。
- `report.pdf`：243页累计译校核查报告；`report.tex` 为工程入口。
- `report_single.tex`：报告的完整独立TeX。
- `PROGRESS.md`：真实完成范围、下一接续点与未译范围。
- `checks/`：来源哈希、结构检查、当前日志分析、构建对照、选定页面渲染及视觉记录。
- `history/`：历史版本记录，不作本轮校验结果使用。

本轮连续译入第0章22.6—22.7，止于（22.7.7，ii）末尾。第0章现连续收入§§1—22。
下一接续点为§23“日本环”及（23.1.1）。第IV章主体与第五卷预备笔记余文仍未全部译入。
正文使用校订形式，原文错误及修改依据在脚注，长反例与证明在核查报告。
历史报告保留当时内容，不表示本轮重新审定了全部历史判断。

## 编译
需要XeLaTeX及TeX Live中的CTeX、AMS、TikZ-cd等标准宏包。
字体由CTeX文档类默认选择，不附字体文件，不依赖外部图片。
在工程根目录执行：
```bash
bash build.sh
```
构建并校验独立单文件版：
```bash
bash build.sh --verify-single
python3 checks/check_structure.py
python3 checks/verify_outputs.py
```
结构校验仅使用Python标准库；PDF逐页文字及72 dpi像素对照需要PyMuPDF（`pip install pymupdf`）。
渲染一致性在同一渲染器、同一字号与编译环境中比较，不要求不同操作系统选择的默认字体完全一致。
也可把 `single.tex` 或 `report_single.tex` 单独置于一个目录，运行XeLaTeX三遍。
`single_build/` 中的重复PDF、辅助文件可由脚本重新生成，发行包不重复存放。

## 版式
使用实际的 `ctexbook` 文档类，沿用默认字体、字号、版心、标题、页眉与双面分页。
原章号、条目号和公式号保留；四位数目录页码栏沿用前版宽度修正，不更改正文版心。
原著页码与合订本页码不同，原著目录和索引仍保留原版页码。

## 检查边界
当前页数与检查结果见 `checks/CHECKS.md`、`checks/output_verification.json`。
视觉复核集中在新增正文、报告、目录和本轮修改页；没有宣称人工逐页重新审定全部旧正文。
全页构建一致性也不等于每个数学命题已经独立证明正确。
发行包不附原著PDF或字体文件。
