"""Render the new/modified pages and compact contact sheets for visual review."""
from pathlib import Path
import hashlib
import json
import math
import fitz
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'checks'/'renders'
OUT.mkdir(exist_ok=True)
sets=[('book_new','main.pdf',list(range(416,430))),
      ('report_new','report.pdf',list(range(15,25))),
      ('book_front','main.pdf',[1,3,4,5,6,7,8,17,18]),
      ('book_errata','main.pdf',[1036,1037,1038]),
      ('report_front','report.pdf',[1,3,5,6])]
record={}
for key,filename,pages in sets:
    pdf=ROOT/filename
    doc=fitz.open(pdf)
    tiles=[]
    for pg in pages:
        image=OUT/f'{key}_{pg:04}.png'
        doc[pg-1].get_pixmap(dpi=100,alpha=False).save(image)
        im=Image.open(image).convert('RGB')
        im.thumbnail((420,600))
        tile=Image.new('RGB',(440,635),'#dddddd')
        tile.paste(im,((440-im.width)//2,25))
        ImageDraw.Draw(tile).text((12,7),f'{filename} / PDF page {pg}',fill='black')
        tiles.append(tile)
    for first in range(0,len(tiles),9):
        group=tiles[first:first+9]
        sheet=Image.new('RGB',(1320,math.ceil(len(group)/3)*635),'white')
        for j,tile in enumerate(group):
            sheet.paste(tile,((j%3)*440,(j//3)*635))
        sheet.save(OUT/f'{key}_contact_{first//9+1}.png')
    record[key]={'pdf':filename,'pages':pages,'render_dpi':100,
                 'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
for filename,pages in [('main.pdf',[418,420,421,423,425,427,1037]),('report.pdf',[16,17,18,19,21])]:
    doc=fitz.open(ROOT/filename)
    for pg in pages:
        doc[pg-1].get_pixmap(dpi=160,alpha=False).save(OUT/f'{Path(filename).stem}_detail_{pg:04}.png')
(OUT/'rendered_pages.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
print('Rendered',len({(f,p) for _,f,ps in sets for p in ps}),'distinct selected pages')
