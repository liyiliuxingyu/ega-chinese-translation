"""Verify preservation of the v14 mathematical sources and new v15 entry coverage.
Run from any working directory. Uses only the Python standard library.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
CHECKS = ROOT / "checks"
spec = importlib.util.spec_from_file_location("flatten_sources", ROOT / "flatten_sources.py")
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)
book = module.expand(ROOT / "main.tex")
report = module.expand(ROOT / "report.tex")
assert book == (ROOT / "single.tex").read_text(encoding="utf-8")
assert report == (ROOT / "report_single.tex").read_text(encoding="utf-8")
previous = json.loads((CHECKS / "baseline_v14_counters.json").read_text())
patterns = {
    "entries": r"\\(?:egap|egas|egapar|egastatement)\{([^}]+)\}",
    "tags": r"\\tag\{([^}]+)\}",
}
result = {}
for key, pattern in patterns.items():
    new = re.findall(pattern, book)
    old_count, new_count = Counter(previous[key]), Counter(new)
    result[key] = {"old_total": len(previous[key]), "new_total": len(new),
                   "missing": dict(old_count - new_count), "added": dict(new_count - old_count)}
    assert not result[key]["missing"], result[key]
for key, filename in (("math_files", "baseline_v14_math_sha256.json"),
                      ("historical_report_files", "baseline_v14_reports_sha256.json")):
    old = json.loads((CHECKS / filename).read_text())
    changed = [name for name, digest in old.items()
               if not (ROOT / name).is_file() or hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    result[key] = {"baseline_count": len(old), "changed": changed}
    assert not changed, changed
new_text = "\n".join((ROOT / "continuations" / name).read_text()
                     for name in ("iv0_22_6.tex", "iv0_22_7.tex"))
expected = [f"22.6.{i}" for i in range(1, 10)] + [f"22.7.{i}" for i in range(1, 8)] + ["22.7.2.4"]
new_entries = re.findall(patterns["entries"], new_text)
assert Counter(new_entries) == Counter(expected), new_entries
result["new_files"] = {"original_entries": new_entries,
                       "original_tags": re.findall(patterns["tags"], new_text),
                       "diagrams": new_text.count(r"\begin{tikzcd}"),
                       "footnote_ids": re.findall(r"\\cmt\{([^}]+)\}", new_text)}
assert len(result["new_files"]["original_tags"]) == 12
assert result["new_files"]["diagrams"] == 2
assert len(result["new_files"]["footnote_ids"]) == 12
(CHECKS / "structure_verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False, indent=2))
