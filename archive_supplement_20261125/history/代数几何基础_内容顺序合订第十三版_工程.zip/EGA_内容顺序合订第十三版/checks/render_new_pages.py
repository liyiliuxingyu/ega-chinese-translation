#!/usr/bin/env python3
"""Render final new/changed pages and contact sheets (PyMuPDF + Pillow)."""
from pathlib import Path
import json,fitz
from PIL import Image,ImageOps,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'checks/rendered';OUT.mkdir(exist_ok=True)
records={}
for name in ['main','report']:
    d=fitz.open(ROOT/(name+'.pdf'));toc=d.get_toc()
    if name=='main':
        start=next(x[2] for x in toc if x[1].startswith('§22 '))
        end=next(x[2] for x in toc if x[1].startswith('第I章'))-1
        err=next(x[2] for x in toc if '本版补入的22.1' in x[1])
        remain=next(x[2] for x in toc if x[1]=='第IV章及后续材料的待译范围')
        pages=sorted(set(list(range(start,end+1))+[1,3,4,5,6,18,19,remain,err,err+1]))
        records[name]={'new_body_range':[start,end],'errata_page':err,'remaining_scope_page':remain}
    else:
        start=next(x[2] for x in toc if x[1].startswith('第十三版新核查'))
        end=next(x[2] for x in toc if x[1].startswith('历史核查记录：第十二版'))-1
        pages=sorted(set([1,3,4,5,6]+list(range(start,end+1))))
        records[name]={'new_audit_range':[start,end]}
    images=[]
    for page in pages:
        pix=d[page-1].get_pixmap(matrix=fitz.Matrix(120/72,120/72),alpha=False)
        path=OUT/f'{name}_{page:04}.png';pix.save(path);images.append((page,path))
    records[name]['rendered_pages']=pages
    for index in range(0,len(images),6):
        sheet=Image.new('RGB',(1000,1440),'#ddd')
        draw=ImageDraw.Draw(sheet)
        for j,(page,path) in enumerate(images[index:index+6]):
            im=Image.open(path);im.thumbnail((480,670))
            x=(j%2)*500+(500-im.width)//2;y=(j//2)*480+22
            # Use a fitted cell of height 450 for each of three rows.
            im.thumbnail((480,450));x=(j%2)*500+(500-im.width)//2
            sheet.paste(im,(x,y));draw.text(((j%2)*500+15,(j//2)*480+5),f'{name} PDF page {page}',fill='black')
        sheet.save(OUT/f'{name}_contact_{index//6+1}.jpg',quality=90)
(ROOT/'checks/rendered_pages.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps(records,ensure_ascii=False,indent=2))
