#!/usr/bin/env python3
"""Compare real split-source and standalone PDF builds, page by page.
Requires PyMuPDF. This checks construction equivalence, not mathematical correctness.
"""
from pathlib import Path
import hashlib,json,time,multiprocessing as mp
import fitz
ROOT=Path(__file__).resolve().parents[1]

def compare(spec):
    name,rel_a,rel_b=spec
    start=time.time()
    a,b=fitz.open(ROOT/rel_a),fitz.open(ROOT/rel_b)
    result={'name':name,'files':[rel_a,rel_b],'page_counts':[len(a),len(b)],'dpi':72,'renderer':'PyMuPDF '+fitz.VersionBind,'text_mismatches':[],'pixel_mismatches':[]}
    if len(a)!=len(b):
        result['passed']=False
        return result
    hashes=[]
    for i,(pa,pb) in enumerate(zip(a,b),1):
        ta,tb=pa.get_text(),pb.get_text()
        ha=hashlib.sha256(ta.encode()).hexdigest(); hb=hashlib.sha256(tb.encode()).hexdigest()
        if ha!=hb:result['text_mismatches'].append(i)
        ima=pa.get_pixmap(matrix=fitz.Matrix(1,1),colorspace=fitz.csRGB,alpha=False)
        imb=pb.get_pixmap(matrix=fitz.Matrix(1,1),colorspace=fitz.csRGB,alpha=False)
        pha=hashlib.sha256(ima.samples).hexdigest();phb=hashlib.sha256(imb.samples).hexdigest()
        if (ima.width,ima.height,pha)!=(imb.width,imb.height,phb): result['pixel_mismatches'].append(i)
        hashes.append({'page':i,'text_sha256':ha,'pixel_sha256':pha,'image_size':[ima.width,ima.height]})
    (ROOT/'checks'/f'{name}_page_hashes.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2))
    result['passed']=not result['text_mismatches'] and not result['pixel_mismatches']
    result['seconds']=round(time.time()-start,3)
    return result

if __name__=='__main__':
    specs=[('book','main.pdf','single_build/book_single.pdf'),('report','report.pdf','single_build/audit_single.pdf')]
    with mp.Pool(2) as pool: results=pool.map(compare,specs)
    (ROOT/'checks/output_comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False,indent=2))
    if not all(x['passed'] for x in results):raise SystemExit(1)
