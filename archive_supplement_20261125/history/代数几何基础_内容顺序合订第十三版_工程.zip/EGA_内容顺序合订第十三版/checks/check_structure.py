#!/usr/bin/env python3
"""Validate entry/tag preservation and SHA256 of retained V12 mathematical files."""
from pathlib import Path
from collections import Counter
import re, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
baseline=json.loads((ROOT/'checks/baseline_v12_sha256.json').read_text())
print(type(baseline),len(baseline))
oldcounts=json.loads((ROOT/'checks/baseline_v12_counters.json').read_text())
new=(ROOT/'single.tex').read_text()
result={}
for name,pat in [('entry_macros',r'\\(?:egastatement|egapar|egas|egap)\{([^}]+)'),('formula_tags',r'\\tag\{([^}]+)')]:
    a,b=Counter(oldcounts[name]),Counter(re.findall(pat,new))
    result[name]={'old_count':sum(a.values()),'new_count':sum(b.values()),'missing':dict(a-b),'added':dict(b-a)}
unchanged=[];changed=[];missing=[]
for rel,h in baseline.items():
    p=ROOT/rel
    if not p.exists():missing.append(rel);continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    (unchanged if got==h else changed).append(rel)
result['retained_files']={'unchanged':unchanged,'changed':changed,'missing':missing}
result['unchanged_math_body_count']=sum(x.startswith(('text/','continuations/')) and x!='text/remaining.tex' for x in unchanged)
result['changed_historical_reports']=[x for x in changed if x.startswith('reports/')]
new_files=['continuations/iv0_22_1.tex','continuations/iv0_22_2a.tex','continuations/iv0_22_2b.tex','continuations/iv0_22_3.tex']
nt=''.join((ROOT/x).read_text() for x in new_files)
result['new_text']={'files':new_files,'entries':re.findall(r'\\ega[ps]\{([^}]+)',nt),'tags':re.findall(r'\\tag\{([^}]+)',nt),'footnotes':re.findall(r'\\cmt\{([^}]+)',nt),'tikzcd_blocks':nt.count(r'\begin{tikzcd}'),'numbered_prose_conditions':['22.1.3.1','22.1.3.2','22.1.3.3']}
result['passed']=not missing and not result['changed_historical_reports'] and all(not result[x]['missing'] for x in ['entry_macros','formula_tags'])
(ROOT/'checks/structure_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='retained_files'},ensure_ascii=False,indent=2))
if not result['passed']:raise SystemExit(1)
