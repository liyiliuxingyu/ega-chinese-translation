#!/usr/bin/env python3
"""Sanity check for M13-N03 over F_2(s); the report supplies the proof."""
from pathlib import Path
import json
import sympy as sp
s,x,y=sp.symbols('s x y')
G=sp.groebner([x*x-s*y*y,y**3],x,y,domain=sp.GF(2).frac_field(s))
nf=lambda f:str(G.reduce(f)[1])
result={'field':'F_2(s)','relations':['x^2-s*y^2','y^3'],'groebner_basis':[str(q) for q in G.polys],'normal_form_y_squared':nf(y*y),'normal_form_x_y_squared':nf(x*y*y),'degree_four_normal_forms':{f'x^{i} y^{4-i}':nf(x**i*y**(4-i)) for i in range(5)},'interpretation':'Independent algebraic sanity check, not a substitute for the written proof.'}
assert result['normal_form_y_squared']!='0'
assert all(v=='0' for v in result['degree_four_normal_forms'].values())
(Path(__file__).resolve().parent/'char2_example.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
