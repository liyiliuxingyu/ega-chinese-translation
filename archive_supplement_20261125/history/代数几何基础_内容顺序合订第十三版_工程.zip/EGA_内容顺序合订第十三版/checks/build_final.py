#!/usr/bin/env python3
"""Final four-way build; independent single files start in clean directories."""
from pathlib import Path
import subprocess,json,time,shutil,concurrent.futures
R=Path(__file__).resolve().parents[1]
def build(spec):
 name,wd=spec; out=[]
 for k in (1,2,3):
  cmd=['xelatex','-interaction=nonstopmode','-halt-on-error']+(['-no-pdf'] if k<3 else [])+[name+'.tex']
  started=time.time()
  with (wd/f'{name}.pass{k}.log.txt').open('w') as f:
   proc=subprocess.run(cmd,cwd=wd,stdout=f,stderr=subprocess.STDOUT)
  out.append({'pass':k,'returncode':proc.returncode,'seconds':round(time.time()-started,2)})
  if proc.returncode: break
 return {'name':name,'directory':str(wd.relative_to(R)),'passes':out,'passed':len(out)==3 and all(x['returncode']==0 for x in out)}
if __name__=='__main__':
 subprocess.run(['python3','flatten_sources.py'],cwd=R,check=True)
 S=R/'single_build';S.mkdir(exist_ok=True)
 for p in S.iterdir():
  if p.is_file():p.unlink()
 shutil.copy(R/'single.tex',S/'book_single.tex');shutil.copy(R/'report_single.tex',S/'audit_single.tex')
 specs=[('main',R),('report',R),('book_single',S),('audit_single',S)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(build,specs))
 (R/'checks/build_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(json.dumps(results,ensure_ascii=False,indent=2))
 if not all(x['passed'] for x in results):raise SystemExit(1)
