# 代数几何基础·中文译校合订本（第十二版）

## 文件
- main.pdf / main.tex：合订本，1008页；main.tex读取分章节源码。
- single.tex：合订本可独立编译的完整单文件，不依赖外部图像、其他TeX文件或第一卷工程。
- report.pdf / report.tex：累计核查报告，209页。
- report_single.tex：报告可独立编译单文件。
- PROGRESS.md：实际范围、原文接续点、未译范围。
- checks/：源文件哈希、结构检查、最终编译日志、逐页文字及像素对照、视觉抽查记录。
- history/：继承的历史记录和第十一版的范围说明；不代表本版重新核查全部旧判断。

## 编译
需安装XeLaTeX、CTeX、AMS、TikZ-cd等标准TeX Live宏包；使用CTeX默认字体，不附带字体文件。
在工程根目录执行：
```bash
bash build.sh
```
将自动展开单文件，并编译合订本、报告。独立单文件检查可执行：
```bash
bash build.sh --verify-single
```
或者只将single.tex复制到任一干净目录，连续运行：
```bash
xelatex -interaction=nonstopmode -halt-on-error single.tex
xelatex -interaction=nonstopmode -halt-on-error single.tex
xelatex -interaction=nonstopmode -halt-on-error single.tex
```
报告同理。默认双面排版可能产生空白偶数页，这是类的正常行为。

## 本版内容
从第十一版接续，新增第0章21.5—21.9全文，止于21.9.8及其证明，完成§21。
正文采用已核定的校订形式，原文错误和依据放脚注，长反例和证明收入独立报告。
本版不是全部材料的完结全译本；第0章§§22—23、第IV章主体、第五卷预备笔记余文仍待译。
原著版权及底本说明保留于书末；译校稿用于对照研读，不等同于独立出版审定。
