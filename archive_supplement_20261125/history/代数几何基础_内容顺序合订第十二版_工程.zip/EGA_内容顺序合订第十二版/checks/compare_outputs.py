from pathlib import Path
import fitz,hashlib,json,time,multiprocessing as mp,re
P=Path(__file__).resolve().parents[1]
def compare(pair):
    name,a,b=pair;t0=time.monotonic()
    da=fitz.open(P/a);db=fitz.open(P/b)
    if len(da)!=len(db):return {'name':name,'pages':len(da),'single_pages':len(db),'error':'page count mismatch'}
    text_mismatch=[];pixel_mismatch=[];details=[]
    for i in range(len(da)):
        ta=da[i].get_text();tb=db[i].get_text()
        ha=hashlib.sha256(ta.encode()).hexdigest();hb=hashlib.sha256(tb.encode()).hexdigest()
        if ha!=hb:text_mismatch.append(i+1)
        pa=da[i].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False,colorspace=fitz.csRGB)
        pb=db[i].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False,colorspace=fitz.csRGB)
        ra=hashlib.sha256(pa.samples).hexdigest();rb=hashlib.sha256(pb.samples).hexdigest()
        if (pa.width,pa.height,ra)!=(pb.width,pb.height,rb):pixel_mismatch.append(i+1)
        details.append({'page':i+1,'text_sha256':ha,'raster_sha256_72dpi':ra,'single_text_sha256':hb,'single_raster_sha256_72dpi':rb})
    (P/'checks'/f'{name}_page_hashes.json').write_text(json.dumps(details,indent=2))
    return {'name':name,'pages':len(da),'text_mismatch_pages':text_mismatch,'pixel_mismatch_pages_72dpi':pixel_mismatch,'seconds':round(time.monotonic()-t0,2)}
if __name__=='__main__':
    pairs=[('book','main.pdf','single_build/book_single.pdf'),('report','report.pdf','single_build/audit_single.pdf')]
    with mp.Pool(2) as pool:res=pool.map(compare,pairs)
    (P/'checks/output_comparison.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
    print(json.dumps(res,ensure_ascii=False,indent=2))
