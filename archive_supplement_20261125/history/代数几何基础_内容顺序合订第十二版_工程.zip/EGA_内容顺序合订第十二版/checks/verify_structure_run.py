from pathlib import Path
import json,hashlib,re,sys
P=Path('/mnt/data/ega12/EGA_内容顺序合订第十二版')
base=json.loads((P/'checks/baseline_v11_sha256.json').read_text())
changed=[];unchanged=[]
for rel,digest in base.items():
    p=P/rel
    h=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    (unchanged if h==digest else changed).append(rel)
newnames=['iv0_21_5','iv0_21_6','iv0_21_7','iv0_21_8','iv0_21_9a','iv0_21_9b','iv0_21_9c']
newtxt='\n'.join((P/'continuations'/f'{n}.tex').read_text() for n in newnames)
sys.path.insert(0,str(P));import flatten_sources
new=flatten_sources.expand(P/'main.tex')
old=Path('/mnt/data/代数几何基础_按内容顺序合订本_第十一版.tex').read_text()
entry_pat=r'\\(?:parnum|stmt|egap|egas)\{([^}]+)\}'
# Discover all inherited numbering macros, and retain the historical egap/egas based count separately.
for name in ['parnum','stmt','egap','egas','numpar','prop','itemnum']:
 c=len(re.findall(r'\\'+name+r'\{',old))
 if c: print(name,c)
old_es=re.findall(r'\\ega[ps]\{([^}]+)',old);new_es=re.findall(r'\\ega[ps]\{([^}]+)',new)
old_tags=re.findall(r'\\tag\{([^}]+)',old);new_tags=re.findall(r'\\tag\{([^}]+)',new)
from collections import Counter
missing_e=list((Counter(old_es)-Counter(new_es)).elements());missing_t=list((Counter(old_tags)-Counter(new_tags)).elements())
result={
 'baseline_files':len(base),'unchanged_files':len(unchanged),'changed_baseline_files':changed,
 'unchanged_existing_mathematical_body_files':len([r for r in unchanged if (r.startswith('text/') and r!='text/remaining.tex') or r.startswith('continuations/')]),
 'new_entry_macros':len(re.findall(r'\\ega[ps]\{',newtxt)),
 'new_formula_tags':len(re.findall(r'\\tag\{',newtxt)),
 'new_notes':len(re.findall(r'\\cmt\{',newtxt)),
 'new_tikzcd_blocks':newtxt.count(r'\begin{tikzcd}'),
 'old_entry_macros_egap_egas':len(old_es),'new_entry_macros_egap_egas':len(new_es),
 'old_tags':len(old_tags),'new_tags':len(new_tags),
 'missing_old_entry_multiset':missing_e,'missing_old_tag_multiset':missing_t,
 'new_entry_ids':re.findall(r'\\ega[ps]\{([^}]+)',newtxt),
 'new_note_ids':re.findall(r'\\cmt\{([^}]+)',newtxt),
 'new_files':[f'continuations/{n}.tex' for n in newnames],
 'old_mathematical_text_claim':'unchanged hashes are preservation checks, not a new translation or mathematical audit'
}
(P/'checks/structure_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
