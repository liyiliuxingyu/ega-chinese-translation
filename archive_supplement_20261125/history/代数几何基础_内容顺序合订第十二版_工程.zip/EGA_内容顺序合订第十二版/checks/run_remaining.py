from pathlib import Path
import subprocess,json,time,sys
P=Path(__file__).resolve().parents[1]
name=sys.argv[1]
result=[]
for passno in [2,3]:
    command=['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error']
    if passno==2: command.append('-no-pdf')
    command.append(name+'.tex')
    t=time.monotonic()
    with (P/(name+'.finalpass'+str(passno)+'.txt')).open('wb') as f:
        proc=subprocess.run(command,cwd=P,stdout=f,stderr=subprocess.STDOUT,timeout=420)
    result.append({'pass':passno,'returncode':proc.returncode,'seconds':round(time.monotonic()-t,2)})
    (P/'checks'/(name+'_build_status.json')).write_text(json.dumps(result,indent=2))
    if proc.returncode: sys.exit(proc.returncode)
