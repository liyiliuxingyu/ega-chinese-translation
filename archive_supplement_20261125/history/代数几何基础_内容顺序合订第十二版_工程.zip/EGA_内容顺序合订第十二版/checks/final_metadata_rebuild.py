from pathlib import Path
import subprocess,json,time,sys
P=Path(__file__).resolve().parents[1]
name=sys.argv[1];cwd=P if name=='main' else P/'single_build'
result=[]
for n in [1,2]:
 cmd=['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error']
 if n==1:cmd+=['-no-pdf']
 cmd+=[name+'.tex'];t=time.monotonic()
 with (cwd/(name+'.metadata'+str(n)+'.txt')).open('wb') as out:
  p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 result.append({'pass':n,'returncode':p.returncode,'seconds':round(time.monotonic()-t,2)})
 (P/'checks'/(name+'_metadata_build_status.json')).write_text(json.dumps(result,indent=2))
 if p.returncode:sys.exit(p.returncode)
