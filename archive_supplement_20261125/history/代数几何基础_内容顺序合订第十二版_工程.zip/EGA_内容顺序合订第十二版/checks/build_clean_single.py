from pathlib import Path
import subprocess,json,time,sys
P=Path(__file__).resolve().parents[1];S=P/'single_build'
name=sys.argv[1];result=[]
for n in [1,2,3]:
 command=['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error']
 if n<3:command+=['-no-pdf']
 command+=[name+'.tex'];t=time.monotonic()
 with (S/(name+'.pass'+str(n)+'.txt')).open('wb') as out:
  proc=subprocess.run(command,cwd=S,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 result.append({'pass':n,'returncode':proc.returncode,'seconds':round(time.monotonic()-t,2)})
 (P/'checks'/(name+'_build_status.json')).write_text(json.dumps(result,indent=2))
 if proc.returncode:sys.exit(proc.returncode)
