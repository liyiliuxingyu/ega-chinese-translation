#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for i in 1 2 3; do
  xelatex -no-pdf -interaction=nonstopmode -halt-on-error main.tex
done
xdvipdfmx -o 代数几何基础_中文合订本.pdf main.xdv
