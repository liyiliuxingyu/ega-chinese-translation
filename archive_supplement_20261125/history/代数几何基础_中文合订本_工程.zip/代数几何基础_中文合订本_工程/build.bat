@echo off
chcp 65001 >nul
cd /d "%~dp0"
for %%i in (1 2 3) do (
  xelatex -no-pdf -interaction=nonstopmode -halt-on-error main.tex
  if errorlevel 1 exit /b 1
)
xdvipdfmx -o "代数几何基础_中文合订本.pdf" main.xdv
if errorlevel 1 exit /b 1
