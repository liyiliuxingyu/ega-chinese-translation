# 代数几何基础：中文译稿合订本

## 内容

合订本包含第一卷《概形的语言》（V2 校订稿）、第二卷《若干类态射的初等整体研究》、第三卷《凝聚层的上同调研究》第一部分。第三卷仅含已译的第一部分，不是整个第三卷，更不是整套 EGA 全集。

这是一份由现有 TeX 正文统一编译的合订本，而非将三个 PDF 的页面简单拼接。原有正文、命题及条目号、公式号、交换图、原注及既有译注予以保留。各卷参考文献、索引、原著目录及版权材料分别保存。

## 排版

文档类为 `\documentclass[UTF8,a4paper]{ctexbook}`。使用 CTeX 默认中文字体、默认字号、默认版心、默认页眉和标题样式，保留默认双面及右页开章行为。没有加载 geometry 或 fancyhdr，也没有指定或附送字体文件。为保留 EGA 引文体系，章号采用原有 0、I、II、III，节及小节保持原著编号。

共 681 页：前置部分 14 页，正文及各卷附录连续编号 1—667。部分空白偶数页属于默认双面书籍排版。新总目录引用合订本页码；原著目录内保留的底本页码不能当作合订本页码。

## 第二卷文件恢复说明

本次无法取回此前声称为第二卷最终版的附件。可核验的本地连续源码完整保存正文至 (8.14.14)。本合订本保留该正文，并依据用户上传的 EGAII.pdf 重新译排书末参考文献 [23]—[26]、记号索引、术语索引、原著目录和《勘误与增补（清单一）》。说明已写入合订本，未将此过程表述为恢复到了原来的最终源码。

## 文件

- main.tex：分文件工程入口。
- preamble.tex：统一宏定义与 CTeX 设置。
- frontmatter.tex：封面、合订说明及总目录。
- sections/volume_1.tex、volume_2.tex、volume_3.tex：分卷正文及各自书末材料。
- 代数几何基础_中文合订本.tex：可独立编译的单文件源码；不需要 main.tex、分卷文件、原版 PDF 或外部图片。
- restoration/II_appendix.tex：第二卷本次恢复的书末材料副本，仅供追踪；已内嵌在 volume_2.tex，编译时不要再次输入。
- PROGRESS.md、VALIDATION.md、checks/：版本及检查记录。

## 编译

需要含 ctex、Fandol、amsmath、mathrsfs、tikz-cd、enumitem、longtable、booktabs、footmisc、adjustbox、hyperref 和 bookmark 等宏包的 TeX Live 或相应 LaTeX 发行版。采用 XeLaTeX，不要用 pdfLaTeX。

Linux/macOS：运行 `bash build.sh`。
Windows：运行 `build.bat`，或在 TeX 编辑器中选择 XeLaTeX，对 main.tex 连续编译三次。

单文件源码也可以独立采用以下命令（执行三遍，使目录与逐页脚注编号稳定）：

```sh
xelatex -interaction=nonstopmode -halt-on-error 代数几何基础_中文合订本.tex
```

## 范围与限制

这次是合订、源文件恢复与版面检查，不是全书新的逐句对译或数学逻辑审定。先前的独立逻辑核查报告和法文标注版未混入翻译正文。原有译注保留；未将核查意见静默写成原著断言。读者仍应把本书视为对照研读用工作译稿。
