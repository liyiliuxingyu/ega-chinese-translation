#!/usr/bin/env python3
"""Check the actual source inventory; optional comparison against the prior source."""
from pathlib import Path
import re,json,sys,collections
ROOT=Path(__file__).resolve().parents[1]
ENTRY=re.compile(r'\\(?:egapar|egastatement|egap|egas)\{([^{}]+)\}')
TAG=re.compile(r'\\tag\*?\{([^{}]+)\}')
ENV=re.compile(r'\\begin\{(tikzcd|equation\*?|align\*?|gather\*?|longtable)\}')
def inventory(text):
 return {'entries':dict(collections.Counter(ENTRY.findall(text))), 'tags':dict(collections.Counter(TAG.findall(text))), 'environments':dict(collections.Counter(ENV.findall(text)))}
new=(ROOT/'single.tex').read_text()
result={'current':inventory(new)}
if len(sys.argv)>1:
 old=Path(sys.argv[1]).read_text();oldi=inventory(old);newi=inventory(new)
 result['previous']=oldi
 result['missing_previous_entries']={k:v-newi['entries'].get(k,0) for k,v in oldi['entries'].items() if newi['entries'].get(k,0)<v}
 result['missing_previous_formula_tags']={k:v-newi['tags'].get(k,0) for k,v in oldi['tags'].items() if newi['tags'].get(k,0)<v}
newentries=[]
for f in sorted((ROOT/'continuations').glob('*.tex')):newentries.extend(ENTRY.findall(f.read_text()))
result['new_continuation_entry_count']=len(newentries)
result['new_continuation_unique_entry_count']=len(set(newentries))
result['new_continuation_ids']=newentries
result['scope_note']='编号核对不等于逐句译文或数学证明的独立审定。'
(ROOT/'checks/content_inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['current','previous','new_continuation_ids']},ensure_ascii=False,indent=2))
