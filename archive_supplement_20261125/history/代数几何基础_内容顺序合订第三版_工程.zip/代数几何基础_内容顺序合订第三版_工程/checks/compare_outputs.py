#!/usr/bin/env python3
"""Compare text and 72-dpi pixel data of multi-file vs single-file builds.
Requires PyMuPDF. This test is not a mathematical proof checker.
"""
from pathlib import Path
import json, hashlib
import fitz
ROOT = Path(__file__).resolve().parents[1]
def compare(a:Path,b:Path):
    if not a.is_file() or not b.is_file():
        raise FileNotFoundError('请先运行 bash build.sh --verify-single')
    da,db=fitz.open(a),fitz.open(b)
    if len(da)!=len(db):
        return {'pages_a':len(da),'pages_b':len(db),'equal':False}
    items=[]
    for i,(p,q) in enumerate(zip(da,db),1):
        x=p.get_pixmap(matrix=fitz.Matrix(1,1),alpha=False)
        y=q.get_pixmap(matrix=fitz.Matrix(1,1),alpha=False)
        items.append({'page':i,'text_equal':p.get_text()==q.get_text(),
                      'render_equal':x.width==y.width and x.height==y.height and x.samples==y.samples,
                      'render_sha256':hashlib.sha256(x.samples).hexdigest()})
        if i%100==0:print(a.name,i,flush=True)
    return {'pages':len(da),'text_equal':all(x['text_equal'] for x in items),
            'render_equal':all(x['render_equal'] for x in items),'page_results':items}
result={'main':compare(ROOT/'main.pdf',ROOT/'single_build/main_single.pdf'),
        'report':compare(ROOT/'report.pdf',ROOT/'single_build/audit_single.pdf')}
(ROOT/'checks/reproduced_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print({k:{j:v for j,v in x.items() if j!='page_results'} for k,x in result.items()})
