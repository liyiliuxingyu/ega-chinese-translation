#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent

def flatten(path:Path, seen:tuple=()) -> str:
    path=path.resolve()
    if path in seen:
        raise ValueError(f'Recursive input: {path}')
    text=path.read_text(encoding='utf-8')
    def repl(m):
        name=m.group(1)
        nested=ROOT/name
        if not nested.suffix:nested=nested.with_suffix('.tex')
        return '\n% BEGIN '+name+'\n'+flatten(nested,seen+(path,))+'\n% END '+name+'\n'
    return re.sub(r'(?m)^\\input\{([^}]+)\}\s*$',repl,text)

for source,out in [('main.tex','single.tex'),('audit_main.tex','audit_single.tex')]:
    t=flatten(ROOT/source)
    assert '\\input{' not in t
    (ROOT/out).write_text(t,encoding='utf-8')
    print(out,len(t.encode('utf-8')))
