#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v xelatex >/dev/null || { echo '需要安装 XeLaTeX 和 CTeX。' >&2; exit 1; }
command -v xdvipdfmx >/dev/null || { echo '需要安装 xdvipdfmx。' >&2; exit 1; }
if [ "$#" -eq 0 ]; then set -- main audit_main; fi
mkdir -p build_logs
for name in "$@"; do
  case "$name" in main|audit_main|new_translation|single|audit_single) ;; *) echo "不支持的文档：$name" >&2; exit 2;; esac
  for pass in 1 2 3; do
    xelatex -no-pdf -interaction=nonstopmode -halt-on-error "$name.tex" >"build_logs/${name}_${pass}.txt" 2>&1 || { tail -60 "build_logs/${name}_${pass}.txt" >&2; exit 1; }
  done
  xdvipdfmx -q -o "$name.pdf" "$name.xdv"
  echo "生成：$name.pdf"
done
