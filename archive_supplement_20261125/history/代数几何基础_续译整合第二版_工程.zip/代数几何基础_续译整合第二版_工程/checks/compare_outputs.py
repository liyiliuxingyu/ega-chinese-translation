"""Compare independently compiled multi-file and flattened TeX outputs."""
from pathlib import Path
import hashlib, json
import fitz
root = Path(__file__).resolve().parents[1]
results = {}
for name, a, b in [('collection', 'main.pdf', 'standalone/single.pdf'), ('audit', 'audit_main.pdf', 'standalone/audit_single.pdf')]:
    d1, d2 = fitz.open(root/a), fitz.open(root/b)
    r = {'left': a, 'right': b, 'pages_left': len(d1), 'pages_right': len(d2),
         'render_dpi': 72, 'text_mismatch_pages': [], 'pixel_mismatch_pages': [], 'page_size_mismatch': []}
    for n in range(min(len(d1), len(d2))):
        p, q = d1[n], d2[n]
        if p.get_text() != q.get_text(): r['text_mismatch_pages'].append(n+1)
        if p.rect != q.rect: r['page_size_mismatch'].append(n+1)
        x, y = p.get_pixmap(matrix=fitz.Matrix(1,1), alpha=False), q.get_pixmap(matrix=fitz.Matrix(1,1), alpha=False)
        if (x.width, x.height, hashlib.sha256(x.samples).hexdigest()) != (y.width, y.height, hashlib.sha256(y.samples).hexdigest()):
            r['pixel_mismatch_pages'].append(n+1)
    r['identical_text_and_render'] = len(d1)==len(d2) and not any(r[k] for k in ('text_mismatch_pages','pixel_mismatch_pages','page_size_mismatch'))
    results[name] = r
(root/'checks/output_comparison.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
