#!/usr/bin/env python3
"""Finite/symbolic sanity checks; the mathematical proofs remain in the report."""
import json
from pathlib import Path
import sympy as sp

root = Path(__file__).resolve().parent
u, v, w, a, b = sp.symbols('u v w a b')
c = a + b*w
relations = [u*v, 1+(u+v)*c]
G = sp.groebner(relations, u, v, w, domain=sp.QQ.frac_field(a,b))
e1, e2 = -u*c, -v*c
checks = {}
for name, expression in {
    'idempotent_e1': e1**2-e1,
    'idempotent_e2': e2**2-e2,
    'orthogonality': e1*e2,
    'sum_is_one': e1+e2-1,
}.items():
    remainder = sp.factor(G.reduce(sp.expand(expression))[1])
    assert remainder == 0, (name, remainder)
    checks[name] = str(remainder)
# Both quotient components have nonempty coordinate rings: substitute the two branches.
for name, substitution in {
    'branch_u_zero': {u:0, v:-1/c},
    'branch_v_zero': {u:-1/c, v:0},
}.items():
    remainders = [sp.cancel(expr.subs(substitution)) for expr in relations]
    assert all(expr == 0 for expr in remainders)
    checks[name] = [str(x) for x in remainders]
checks['regular_sequence_base_change'] = {
    'original_ring': 'k[t]', 'element': 't',
    'base_change_ring': 'k[t]/(t)',
    'induced_map_on_k_matrix': [[0]],
    'rank': int(sp.zeros(1,1).rank()), 'nonzero_kernel_dimension': 1,
}
checks['cech_cardinality_examples'] = [
    {'homological_h': h, 'printed': -(h+1), 'required': 1-h}
    for h in (0,-1,-2)
]
checks['limitation'] = ('These computations check the written algebraic identities only; '
    'they do not certify all EGA proofs, topological connectedness, or all field characteristics.')
(root/'symbolic_results.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2))
print(json.dumps(checks, ensure_ascii=False, indent=2))
