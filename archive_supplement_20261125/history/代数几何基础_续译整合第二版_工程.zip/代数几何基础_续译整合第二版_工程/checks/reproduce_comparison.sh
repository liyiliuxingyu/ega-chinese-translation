#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 flatten_sources.py
mkdir -p standalone
cp single.tex audit_single.tex standalone/
cd standalone
for name in single audit_single; do
  for pass in 1 2 3; do
    xelatex -no-pdf -interaction=nonstopmode -halt-on-error "$name.tex" >"${name}_${pass}.txt" 2>&1
  done
  xdvipdfmx -q -o "$name.pdf" "$name.xdv"
done
cd ..
python3 checks/compare_outputs.py
