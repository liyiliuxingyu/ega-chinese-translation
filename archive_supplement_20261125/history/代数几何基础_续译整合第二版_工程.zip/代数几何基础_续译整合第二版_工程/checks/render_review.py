from pathlib import Path
import fitz, json
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'checks'/'renders';OUT.mkdir(exist_ok=True)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
results={}
for name in ['main','audit_main','new_translation']:
 d=fitz.open(ROOT/(name+'.pdf'))
 pages=[]
 contacts=[]
 stride=84 if name=='main' else 20
 cols=12 if name=='main' else 5
 cellw=150 if name=='main' else 210
 cellh=int(cellw*1.415)+23
 scale=(cellw-10)/d[0].rect.width
 for start in range(0,len(d),stride):
  batch=list(range(start,min(start+stride,len(d))))
  rows=(len(batch)+cols-1)//cols
  sheet=Image.new('RGB',(cols*cellw,rows*cellh),'#dedede');draw=ImageDraw.Draw(sheet)
  for j,idx in enumerate(batch):
   pg=d[idx]; pix=pg.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
   im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
   x=(j%cols)*cellw+5;y=(j//cols)*cellh+18
   sheet.paste(im,(x,y));draw.text((x,y-16),str(idx+1),font=font,fill='black')
  path=OUT/f'{name}_contact_{start+1:04d}_{start+len(batch):04d}.jpg'
  sheet.save(path,quality=91);contacts.append(str(path))
 for i,pg in enumerate(d):
  text=pg.get_text()
  blocks=pg.get_text('blocks')
  outside=[list(b[:4]) for b in blocks if b[0]<-1 or b[1]<-1 or b[2]>pg.rect.width+1 or b[3]>pg.rect.height+1]
  if outside:pages.append({'physical_page':i+1,'out_of_page_blocks':outside})
 results[name]={'pages':len(d),'size_bytes':(ROOT/(name+'.pdf')).stat().st_size,'toc_entries':len(d.get_toc()),'contacts':contacts,'outside_page':pages}
 # Full-resolution new pages are for close review, not OCR.
 if name=='new_translation':
  for i in range(len(d)):
   pix=d[i].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False)
   pix.save(OUT/f'new_detail_{i+1:03d}.png')
 if name=='audit_main':
  for i in [0,2,8,9,10,11,12,13,14,15,16,17,18,19,20,24,27,39,42,60]:
   if i<len(d):d[i].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(OUT/f'audit_detail_{i+1:03d}.png')
 if name=='main':
  for i in [0,2,3,4,5,14,15,16,660,675,676,677,678,700,715,730,745,758]:
   if i<len(d):d[i].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(OUT/f'main_detail_{i+1:03d}.png')
  (OUT/'main_toc.json').write_text(json.dumps(d.get_toc(),ensure_ascii=False,indent=2))
 (ROOT/'checks'/'render_inventory.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print(name,results[name]['pages'],'pages, out-of-page blocks',len(pages))
