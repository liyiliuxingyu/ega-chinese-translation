# 代数几何基础：中文译校合订本（续译整合第二版）

## 交付内容

- `main.pdf`：759页，前置页i–xvi，正文1–743；所有已经实际译出的内容统一目录、连续正文页码。
- `single.tex`：上述合订本的单文件源码，不需要原扫描PDF、外部图片或第一卷的独立工程。
- `audit_main.pdf`：61页，独立核查报告；含本轮新增核查、上一批新增文稿核查、早期第一与第二卷核查记录。
- `audit_single.tex`：核查报告的独立单文件源码。
- `new_translation.pdf`：39页，本轮新增译文抽出本，便于单独阅读；正文已全部收入合订本。
- `PROGRESS.md`：实际完成范围、未译范围、接续条目。

本工程是当前已译内容的汇总，不是所上传全部EGA原文的全译本。核查报告不是全书数学正确性的认证。

## 编译

需要带有CTeX、XeLaTeX及所用宏包的完整TeX发行版（例如TeX Live）。字体由CTeX文档类按安装平台默认选择，不附带、也不指定外部商业字体文件。

在本目录运行：

```sh
bash build.sh
```

默认编译合订本和核查报告，每份运行三遍XeLaTeX。构建所有三份PDF：

```sh
bash build.sh main audit_main new_translation
```

独立编译单文件：

```sh
xelatex -interaction=nonstopmode -halt-on-error single.tex
xelatex -interaction=nonstopmode -halt-on-error single.tex
xelatex -interaction=nonstopmode -halt-on-error single.tex
```

核查报告同理，把`single.tex`换成`audit_single.tex`。在其他TeX发行版或字体版本下重编译可能有字形、行距或分页差异。

## 源码组织

`main.tex`调用统一前导、卷首、原有分卷源码和新增连续译文。三个旧分卷源码位于`sections/volume_1.tex`等；本轮与恢复出的旧合订工程逐字节比较相同。上一批新增材料在`sections/batch1_*.tex`，只调整合订结构、停止提示及标题。新翻译在`continuations/`。

`audit_main.tex`调用`reports/`。历史报告为保留记录，未声称每项判断本轮都重新审定。只有核查报告中的明确译校分析属于本次补证或反例；不作为原文的一部分。

运行`python flatten_sources.py`可以重新生成两个单文件源码。该脚本使用Python标准库；不需网络。

## 核验

详见`checks/CHECKS.md`、`checks/output_comparison.json`、`checks/content_inventory.json`、`checks/symbolic_results.json`。本轮分文件工程与独立单文件源码编译后的逐页文字及72 dpi渲染像素一致。全卷已生成渲染缩览；新增页与关键页另行检查，并非宣称759页每个证明都经过独立数学复核。

保留的非致命日志提示包括少量Underfull排版提示和数学花体字号替代。没有在最终日志中发现编译错误、未定义控制序列、缺字、未定义引用或Overfull溢出。字体文件不包含在工程中。
